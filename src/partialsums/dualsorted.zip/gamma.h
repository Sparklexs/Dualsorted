#include "basics.h"
#include "math_utils.h"

uint encode(uint* output, uint pos, uint value);
uint decode(uint* input, uint pos, uint* value);
